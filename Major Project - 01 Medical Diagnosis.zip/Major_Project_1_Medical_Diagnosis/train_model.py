import numpy as np
import joblib

from sklearn.datasets import make_classification
from sklearn.ensemble import RandomForestClassifier

# Generate sample educational data
X, y = make_classification(
    n_samples=1500,
    n_features=4,
    n_informative=4,
    n_redundant=0,
    random_state=42
)

model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

model.fit(X, y)

joblib.dump(model, "medical_model.pkl")

print("Medical Risk Demo Model Created Successfully!")