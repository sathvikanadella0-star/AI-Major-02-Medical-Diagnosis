# Medical Diagnosis Demo

## Project Description
This project demonstrates an educational health-risk
prediction system using a machine learning model.

## Technologies Used
- Python
- Streamlit
- NumPy
- Scikit-learn
- Joblib

## How To Run

1. Install requirements.
2. Run train_model.py.
3. Run the Streamlit app.

## Disclaimer
This project uses synthetic data and is not intended
for medical diagnosis or treatment.