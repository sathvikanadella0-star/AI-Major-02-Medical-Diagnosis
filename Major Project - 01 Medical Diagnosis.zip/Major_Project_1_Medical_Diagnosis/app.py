import streamlit as st
import numpy as np
import joblib
import os

st.set_page_config(
    page_title="Medical Diagnosis Demo",
    page_icon="🩺"
)

st.title("🩺 Medical Diagnosis Demo")
st.write("Educational Health-Risk Prediction System")

MODEL_PATH = "medical_model.pkl"

if not os.path.exists(MODEL_PATH):
    st.error("Model File Missing. First Run train_model.py")
    st.stop()

model = joblib.load(MODEL_PATH)

st.subheader("Enter Sample Health Values")

value1 = st.number_input("Health Value 1", 0.0, 200.0, 50.0)
value2 = st.number_input("Health Value 2", 0.0, 200.0, 60.0)
value3 = st.number_input("Health Value 3", 0.0, 200.0, 70.0)
value4 = st.number_input("Health Value 4", 0.0, 200.0, 80.0)

if st.button("Predict Health Risk"):
    values = np.array([[value1, value2, value3, value4]])
    prediction = model.predict(values)[0]

    if prediction == 1:
        st.warning("Sample Risk Category: Higher Risk")
    else:
        st.success("Sample Risk Category: Lower Risk")

st.caption(
    "Educational demo using synthetic data. "
    "Not for medical diagnosis or treatment."
)